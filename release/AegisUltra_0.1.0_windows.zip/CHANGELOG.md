# Aegis Ultra Changelog

## v0.1.0
- Bootstrap scaffold with gateway firewall, OPA sidecar, audit ledger, Docker/Windows builds.
